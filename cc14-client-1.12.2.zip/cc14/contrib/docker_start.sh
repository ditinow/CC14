#!/bin/bash
cd /nxt; ./run.sh
