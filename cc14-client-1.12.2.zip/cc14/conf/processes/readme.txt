This directory is used by the EncryptedConfig add-ons in order to store
predefined files which can be safely overwritten.

By default those add-ons only try to create a new file and will fail if the
file exists. These predefined files allow a better UX within the "Processes"
wallet page.
